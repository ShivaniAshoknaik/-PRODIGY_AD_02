
# ToDoList_App
Task manager app using kotlin 

![WhatsApp Image 2023-07-27 at 8 08 44 AM](https://github.com/nidhirk2020/ToDoList_App/assets/96578258/d0c9edec-5365-4928-a5cd-f2b9dc4d791e)
![todo_ss](https://github.com/nidhirk2020/PRODIGY_AD_02/assets/96578258/3f1f40d3-b8d8-464d-a992-dafedc380077)
